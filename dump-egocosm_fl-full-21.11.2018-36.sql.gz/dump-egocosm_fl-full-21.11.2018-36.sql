-- MySQL dump 10.13  Distrib 5.6.39-83.1, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: tmp_jwEXtZEs
-- ------------------------------------------------------
-- Server version	5.6.39-83.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `modx_gallery_album_contexts`
--

DROP TABLE IF EXISTS `modx_gallery_album_contexts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modx_gallery_album_contexts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album` int(10) unsigned NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web',
  PRIMARY KEY (`id`),
  KEY `album` (`album`),
  KEY `context_key` (`context_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modx_gallery_album_contexts`
--

LOCK TABLES `modx_gallery_album_contexts` WRITE;
/*!40000 ALTER TABLE `modx_gallery_album_contexts` DISABLE KEYS */;
/*!40000 ALTER TABLE `modx_gallery_album_contexts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modx_gallery_album_items`
--

DROP TABLE IF EXISTS `modx_gallery_album_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modx_gallery_album_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` int(10) unsigned NOT NULL DEFAULT '0',
  `album` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item` (`item`),
  KEY `album` (`album`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modx_gallery_album_items`
--

LOCK TABLES `modx_gallery_album_items` WRITE;
/*!40000 ALTER TABLE `modx_gallery_album_items` DISABLE KEYS */;
INSERT INTO `modx_gallery_album_items` VALUES (16,16,1,7),(17,17,1,8),(10,10,1,3),(9,9,1,2),(8,8,1,1),(7,7,1,0),(13,13,1,6),(14,14,1,7),(15,15,1,8),(18,18,1,9),(25,25,2,4),(20,20,2,1),(21,21,2,2),(22,22,2,3),(23,23,2,4),(26,26,2,5);
/*!40000 ALTER TABLE `modx_gallery_album_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modx_gallery_albums`
--

DROP TABLE IF EXISTS `modx_gallery_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modx_gallery_albums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `year` varchar(100) DEFAULT NULL,
  `description` text,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `prominent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `watermark` varchar(255) NOT NULL DEFAULT '',
  `cover_filename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `name` (`name`),
  KEY `createdby` (`createdby`),
  KEY `rank` (`rank`),
  KEY `active` (`active`),
  KEY `prominent` (`prominent`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modx_gallery_albums`
--

LOCK TABLES `modx_gallery_albums` WRITE;
/*!40000 ALTER TABLE `modx_gallery_albums` DISABLE KEYS */;
INSERT INTO `modx_gallery_albums` VALUES (1,0,'European Oak','','','2018-11-20 23:46:16',1,0,1,1,'',''),(2,0,'workers','','','2018-11-21 01:07:30',1,1,1,1,'','');
/*!40000 ALTER TABLE `modx_gallery_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modx_gallery_items`
--

DROP TABLE IF EXISTS `modx_gallery_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modx_gallery_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `mediatype` varchar(40) NOT NULL DEFAULT 'image',
  `url` text,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `duration` varchar(40) NOT NULL DEFAULT '',
  `streamer` text,
  `watermark_pos` varchar(10) NOT NULL DEFAULT 'tl',
  PRIMARY KEY (`id`),
  KEY `createdby` (`createdby`),
  KEY `name` (`name`),
  KEY `active` (`active`),
  KEY `mediatype` (`mediatype`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modx_gallery_items`
--

LOCK TABLES `modx_gallery_items` WRITE;
/*!40000 ALTER TABLE `modx_gallery_items` DISABLE KEYS */;
INSERT INTO `modx_gallery_items` VALUES (17,'1c9ea6d96a2aba239a3907f05e0c6253.jpg','1/17.jpg',NULL,'image',NULL,'2018-11-21 00:31:53',1,1,'',NULL,'tl'),(10,'eb21ba48bc5583f0673565832251c1c2.jpg','1/10.jpg',NULL,'image',NULL,'2018-11-20 23:48:34',1,1,'',NULL,'tl'),(9,'30480ed9f990689c90912d0daaad67d4.jpg','1/9.jpg',NULL,'image',NULL,'2018-11-20 23:48:33',1,1,'',NULL,'tl'),(8,'cirrus_3.jpg','1/8.jpg',NULL,'image',NULL,'2018-11-20 23:48:33',1,1,'',NULL,'tl'),(7,'12fd0ac019f2be0331e580453002a8f2.jpg','1/7.jpg',NULL,'image',NULL,'2018-11-20 23:48:33',1,1,'',NULL,'tl'),(16,'9d8efbd215c555b43bb54fe13b81e6ca.jpg','1/16.jpg',NULL,'image',NULL,'2018-11-21 00:31:52',1,1,'',NULL,'tl'),(13,'newburgh-ny-hardwood-floors-kahrs-oak-smoke.jpg','1/13.jpg',NULL,'image',NULL,'2018-11-20 23:48:34',1,1,'',NULL,'tl'),(14,'oak-cornwall2.jpg','1/14.jpg',NULL,'image',NULL,'2018-11-20 23:48:35',1,1,'',NULL,'tl'),(15,'www-ave-parket-ru-max-dub-peristye-oblaka-152N2BEKVVKW-0_6.jpg','1/15.jpg',NULL,'image',NULL,'2018-11-20 23:48:35',1,1,'',NULL,'tl'),(18,'banner-04-tab.jpg','1/18.jpg',NULL,'image',NULL,'2018-11-21 00:31:53',1,1,'',NULL,'tl'),(25,'AdobeStock_72795043.jpeg','2/25.jpeg',NULL,'image',NULL,'2018-11-21 01:15:03',1,1,'',NULL,'tl'),(20,'es_2272018_guvenen_credit_alvarez2.jpg','2/20.jpg',NULL,'image',NULL,'2018-11-21 01:07:41',1,1,'',NULL,'tl'),(21,'manufacturing-workers.jpeg','2/21.jpeg',NULL,'image',NULL,'2018-11-21 01:07:42',1,1,'',NULL,'tl'),(22,'Jobs-EconomySmall.jpg','2/22.jpg',NULL,'image',NULL,'2018-11-21 01:07:42',1,1,'',NULL,'tl'),(23,'redundancy_workers.jpg','2/23.jpg',NULL,'image',NULL,'2018-11-21 01:07:42',1,1,'',NULL,'tl'),(26,'videoblocks-tilt-down-pan-of-female-warehouse-worker-in-hard-hat-and-uniform-talking-with-unrecogniz','2/26.png',NULL,'image',NULL,'2018-11-21 01:15:04',1,1,'',NULL,'tl');
/*!40000 ALTER TABLE `modx_gallery_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modx_gallery_tags`
--

DROP TABLE IF EXISTS `modx_gallery_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modx_gallery_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` int(10) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `item` (`item`),
  KEY `tag` (`tag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modx_gallery_tags`
--

LOCK TABLES `modx_gallery_tags` WRITE;
/*!40000 ALTER TABLE `modx_gallery_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `modx_gallery_tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-21  4:35:05
